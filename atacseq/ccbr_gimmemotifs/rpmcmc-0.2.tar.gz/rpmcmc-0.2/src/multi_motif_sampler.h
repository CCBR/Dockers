#ifndef MULTI_MOTIF_SAMPLER_H
#define MULTI_MOTIF_SAMPLER_H

#include <functional>
#include <iostream>
#include <fstream>
#include <vector>
#include "app.h"

namespace Rmc{

class MultiMotifSampler : public App{
public:
	MultiMotifSampler();
	void set_param_default();
	void set_param(char *argv[]);
	int run();

private:
	void usage();
	void caution(int size, int length);
	int iter;
	int burnin;
	int l_min;
	int l_max;
	int n_motif;
	int markov;
	double lamda;
	double repul;
	double gap;
	double bound_motif;

	std::string m_input_file;
	std::string m_output_dir;
	std::string ps_prior_input;


	class SetParam : public std::unary_function<Param, void>{
	public:
		SetParam(MultiMotifSampler* obj) : m_obj(obj){}
		void operator()(const Param& param);
	private:
		MultiMotifSampler* m_obj;
	};
	friend class SetParam;
};

}
#endif
