/*
	*copy this to 'your_application.cpp' and follow the **NOTE**s below
*/

#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include "app_tmpl.h"
	//**NOTE** replace 'app_tmpl,h' by 'your_application.h'
//**NOTE** include necessary headers

using namespace Rmc;

//**NOTE** replace every 'AppTmpl' below by 'YourApplication'

AppTmpl the_app;

//**NOTE** define static const member variables here if any

//
AppTmpl::AppTmpl(){}

//
void AppTmpl::set_param_default()
{
	//**NOTE**
	// define default values of parameters;
	// replace these lines by definition of actual parameters;
	m_prog = "app_tmpl";
	m_param1 = 0;
	m_param2 = 0;
}

//
void AppTmpl::set_param(char *argv[])
{
	// **NOTE**
	// command line arguments must be listed in <-key value> format
	try {
		parse_argv(argv);
	} catch(BadArgv) {
		usage();
		std::exit(2);
	}
	std::for_each(m_params.begin(), m_params.end(), SetParam(this));
	//**NOTE**
	//check parameters here;
	//if they are invalid, exit the program by calling std::exit(2)
}

//
int AppTmpl::run()
{
	//**NOTE**
	//remove next two lines ...
	std::cout << m_param1 << " " << m_param2 << std::endl;
	if(m_debug) std::cerr << "running in debug mode..." << std::endl;

	//**NOTE**
	//... and do something here

	//**NOTE**
	// in case of error, terminate the program by:
	// return 1;

	return 0;
}

//
void AppTmpl::usage()
{
	using std::cerr;
	using std::endl;
	//**NOTE** modiry the following lines to show usage specific to Your Application
	cerr << "usage: " << m_prog << " [-key value ...]" << endl;
	cerr << "\tpossible keys and values are as follows:" << endl;
	cerr << "\ti:integer value [integer](unique; 0 by default)" << endl;
	cerr << "\td:double-floating-point value [double] (unique; 0.0 by default)" << endl;
	cerr << "\tdebug: run in debug mode if set true [t/f] (f by default)" << endl;
}

//
void AppTmpl::SetParam::operator()(const Param& param)
{
	//**NOTE** modify the following lines to set parameters specific to Your Application
	using std::strcmp;
	if(strcmp(param.key, "i") == 0){
		m_obj->m_param1 = std::atoi(param.value);
	} else if(strcmp(param.key, "d") == 0){
		m_obj->m_param2 = std::atof(param.value);
	} else if(strcmp(param.key, "debug") == 0){
		if(param.value[0] == 't') m_obj->m_debug = true;
		else m_obj->m_debug = false;
	} else {
		std::cerr << "unreorganized parameter " << param.key << std::endl;
		m_obj->usage();
		std::exit(2);
	}
}

//**NOTE** define other member functions below

