#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>
#include <vector>
#include <time.h>
#include "app_tmpl.h"
#include "multi_motif_sampler.h"
#include "fasta_reader.h"
#include "motif_sampler.h"
#include "bio_sequence.h"
#include "motif_info_ext.h"
#include "ps_prior.h"

using namespace Rmc;

MultiMotifSampler the_app;

//
MultiMotifSampler::MultiMotifSampler(){}

//
void MultiMotifSampler::set_param_default()
{
	m_prog = "RPMCMC";
	iter = 520;
	burnin = 20;
	l_min= 6;
	l_max= 14;
	gap = 0.3;
	markov = 0;
	bound_motif = 0.65;
	lamda = 0.3;
	repul = 10.0;
	n_motif = 20;
}

//
void MultiMotifSampler::set_param(char *argv[])
{
	try {
		parse_argv(argv);
	} catch(BadArgv) {
		usage();
		std::exit(2);
	}

	std::for_each(m_params.begin(), m_params.end(), SetParam(this));

	if(m_input_file.empty()==true ){
		usage();
		std::exit(2);
	}
	if(m_output_dir.empty()==true ){
		usage();
		std::exit(2);
	}
	if((iter < 0) || (iter > 10000) ){
		usage();
		std::exit(2);
	}
	if((markov < 0) || (markov > 3) ){
		usage();
		std::exit(2);
	}
	if((burnin > iter) || (burnin < 0) ){
		usage();
		std::exit(2);
	}
	if((l_min > l_max) || (l_max > 30) ){
		usage();
		std::exit(2);
	}
	if(gap < 0){
		usage();
		std::exit(2);
	}
	if((bound_motif <= 0) || (bound_motif > 1) ){
		usage();
		std::exit(2);
	}
}

//
int MultiMotifSampler::run()
{
	std::cout << "###data preprocessing" << std::endl;
	std::vector<BioSequence> batch;
	srand((unsigned)time(NULL));

	BioSequence seq;

	std::ifstream ifs(m_input_file.c_str());
	FastaReader fas(ifs);
	while(fas.read(seq)){
			batch.push_back(seq);
	}

	int max_seqlength = 0;
	for(int i=0; i < batch.size(); i++){
		max_seqlength = std::max(max_seqlength, batch[i].length());
	}

	if((batch.size() <= 0) || (batch.size() > 100000) || (max_seqlength <= 0) || (max_seqlength > 3000)){
		caution(max_seqlength, batch.size());
		std::exit(2);
	}

	int maxcol=0;
	for(int i=0; i<batch.size(); i++){
		maxcol = std::max(maxcol, batch[i].length());
	}

//psp
	PsPrior psp;
	if(ps_prior_input.empty()==false ){
		std::ifstream ifs6(ps_prior_input.c_str());
		psp.set_prior(ifs6);	
		bool chk_flag = false;
		std::cout << "checking position specific prior" << std::endl;
		if(batch.size() != psp.nrow()){chk_flag=true;}
		else{
			for(int i=0; i<psp.nrow(); i++){
				if(batch[i].length() != psp.ncol(i)){chk_flag=true; break;}
			}
		}
		if(chk_flag==true){
			std::cout << "using uniform position specific prior" << std::endl;
			int maxcol=0;
			for(int i=0; i<batch.size(); i++){
				maxcol = std::max(maxcol, batch[i].length());
			}
			psp.set_uniform(batch.size(), maxcol);
		}
		else{
			std::cout << "using input position specific prior" << std::endl;
		}
	}else{
		std::cout << "using uniform position specific prior" << std::endl;
		int maxcol=0;
		for(int i=0; i<batch.size(); i++){
			maxcol = std::max(maxcol, batch[i].length());
		}
		psp.set_uniform(batch.size(), maxcol);
	}
//

	std::ostream* os;
	std::ostream* od;
	os = &std::cout;

	std::string m_output_file1 = m_output_dir;
	m_output_file1 = m_output_file1.append("/locate");
	std::string m_output_file2 = m_output_dir;
	m_output_file2 = m_output_file2.append("/pfm");

	std::ostream* os1 = new std::ofstream(m_output_file1.c_str());
	std::ostream* os2 = new std::ofstream(m_output_file2.c_str());

	std::string m_temp_file1 = m_output_dir;
	m_temp_file1 = m_temp_file1.append("/pos");
	std::string m_temp_file2 = m_output_dir;
	m_temp_file2 = m_temp_file2.append("/dir");
	std::string m_temp_file3 = m_output_dir;
	m_temp_file3 = m_temp_file3.append("/length");
	std::string m_temp_file4 = m_output_dir;
	m_temp_file4 = m_temp_file4.append("/filtered");	
	

	std::ostream* os3 = new std::ofstream(m_temp_file1.c_str());
	std::ostream* os4 = new std::ofstream(m_temp_file2.c_str());
	std::ostream* os5 = new std::ofstream(m_temp_file3.c_str());
	std::ostream* os6 = new std::ofstream(m_temp_file4.c_str());

	MotifSampler sampler(batch, psp, markov, l_min, l_max, repul, n_motif, bound_motif, gap);

	std::cout << "###sampling step" << std::endl;
	int j=0;
	for(int i=0; i < iter; i++){
		std::cout << i+1 << "/" << iter << std::endl;
		sampler.mcmc_motif();

		if(i>=burnin){
		sampler.out_pos(*os3);
		sampler.out_dir(*os4);		
		sampler.out_length(*os5);

		sampler.stock_pwm(i-burnin);
		sampler.stock_weight(i-burnin);
		sampler.stock_likelihood(i-burnin);
		sampler.stock_length(i-burnin);
		sampler.stock_seq_num(i-burnin);
		}
	}


	sampler.filter_motif(0, lamda, 2, 10, *os6);

	std::ifstream ifs2(m_temp_file4.c_str());
	std::ifstream ifs3(m_temp_file1.c_str());
	std::ifstream ifs4(m_temp_file2.c_str());
	std::ifstream ifs5(m_temp_file3.c_str());

	M_MotifInfo info(batch, ifs2 ,ifs3, ifs4, ifs5);

	remove(m_temp_file1.c_str());
	remove(m_temp_file2.c_str());
	remove(m_temp_file3.c_str());
	remove(m_temp_file4.c_str());

	info.out_info(*os1);
	info.out_pwm(*os2);

	if (os1 != &std::cout) delete os1;
	if (os2 != &std::cout) delete os2;
	if (os3 != &std::cout) delete os3;
	if (os4 != &std::cout) delete os4;
	if (os5 != &std::cout) delete os5;


	return 0;
}

//
void MultiMotifSampler::usage()
{
	using std::cerr;
	using std::endl;
	cerr << "##usage: " << m_prog << " [-key value ...]" << endl;
	cerr << "\tod:output directory path:" << endl;
	cerr << "\td:input fasta file path:" << endl;
	cerr << "\tps:input position specific prior file path:(optional; uniform prior by default)" << endl;
	cerr << "\tp:order of markov background model(0<=p<=3)[int] (optional; 0 by default)" << endl;
	cerr << "\tks:motif length min(ks<=kl<=30)[int] (optional; 6 by default)" << endl;
	cerr << "\tkl:motif length max(ks<=kl<=30)[int] (optional; 14 by default)" << endl;
	cerr << "\tn:the number of replicas(1<=n<=100)[int] (optional; 20 by default)" << endl;
	cerr << "\tr:strength of repulsive force(0<=r<=100)[float] (optional; 10.0 by default)" << endl;
	cerr << "\ti:the number of iteration(u<=i<=10000)[int] (optional; 520 by default)" << endl;
	cerr << "\tu:burnin step(0<=u<i)[int] (optional; 20 by default)" << endl;
	cerr << "\tb:prior of motif presence(0<b<=1)[float] (optional; 0.65 by default)" << endl;
	cerr << "\tg:penalty on different length(g>=0)[float] (optional; 0.3 by default)" << endl;
	cerr << "\tl:threshold for clustering(0<=l<=1)[float] (optional; 0.3 by default)" << endl;
	cerr << "\tdebug: run in debug mode if set true [t/f] (f by default)" << endl << endl;
	cerr << "##maximum the number/length of sequence are 100000/3000" << endl << endl;
}

void MultiMotifSampler::caution(int length, int size)
{
	using std::cerr;
	using std::endl;
	cerr << "##caution##" << endl;
	cerr << "    the maximum seq length is 3000 and the maximum size of seqset is 100000" << endl;
	cerr << "    the maximum seq length of your input is " << length << endl;
	cerr << "    the number of sequence in your input seqset is " << size << endl;
	cerr << endl;
	cerr << "    abort this program" << endl;
}

//
void MultiMotifSampler::SetParam::operator()(const Param& param)
{
	using std::strcmp;
	if(strcmp(param.key, "od") == 0){
		m_obj->m_output_dir = param.value;
	} else if(strcmp(param.key, "d") == 0){
		m_obj->m_input_file = param.value;
	} else if(strcmp(param.key, "ps") == 0){
		m_obj->ps_prior_input = param.value;
	} else if(strcmp(param.key, "p") == 0){
		m_obj->markov = std::atof(param.value);
	} else if(strcmp(param.key, "b") == 0){
		m_obj->bound_motif = std::atof(param.value);
	} else if(strcmp(param.key, "n") == 0){
		m_obj->n_motif = std::atoi(param.value);
	} else if(strcmp(param.key, "g") == 0){
		m_obj->gap = std::atof(param.value);
	} else if(strcmp(param.key, "l") == 0){
		m_obj->lamda = std::atof(param.value);
	} else if(strcmp(param.key, "r") == 0){
		m_obj->repul = std::atof(param.value);
	} else if(strcmp(param.key, "i") == 0){
		m_obj->iter = std::atoi(param.value);
	} else if(strcmp(param.key, "u") == 0){
		m_obj->burnin = std::atoi(param.value);
	} else if(strcmp(param.key, "ks") == 0){
		m_obj->l_min = std::atoi(param.value);
	} else if(strcmp(param.key, "kl") == 0){
		m_obj->l_max = std::atoi(param.value);
	} else if(strcmp(param.key, "debug") == 0){
		if(param.value[0] == 't') m_obj->m_debug = true;
		else m_obj->m_debug = false;
	} else {
		std::cerr << "unreorganized parameter " << param.key << std::endl;
		m_obj->usage();
		std::exit(2);
	}
}
