#ifndef RMC_EXCEPTION_H
#define RMC_EXCEPTION_H

#include <iostream>
#include <string>

namespace Rmc{

class Exception{
public:
	Exception(){}
	Exception(const char *m);
	void print_message() const;

private:
	std::string m_message;
};

inline Exception::Exception(const char* m){ m_message = m; }
inline void Exception::print_message() const{ std::cerr << m_message << std::endl; }

}

#endif
