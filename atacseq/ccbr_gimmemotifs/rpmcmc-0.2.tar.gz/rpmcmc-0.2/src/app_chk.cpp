#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <vector>
#include <time.h>
#include "app_tmpl.h"
#include "app_chk.h"
#include "fasta_reader.h"
#include "bio_sequence.h"
#include "motif_info_ext.h"

using namespace Rmc;

AppChk the_app;

//
AppChk::AppChk(){}

//
void AppChk::set_param_default()
{
	m_prog = "tmp";

}

//
void AppChk::set_param(char *argv[])
{
	try {
		parse_argv(argv);
	} catch(BadArgv) {
		usage();
		std::exit(2);
	}
	std::for_each(m_params.begin(), m_params.end(), SetParam(this));

	if(!(m_input_file1) ){
		usage();
		std::exit(2);
	}
	if(!(m_input_file2) ){
		usage();
		std::exit(2);
	}
	if(!(m_input_file3) ){
		usage();
		std::exit(2);
	}
	if(!(m_input_file4) ){
		usage();
		std::exit(2);
	}
	if(!(m_input_file5) ){
		usage();
		std::exit(2);
	}

}

//
int AppChk::run()
{

	std::ostream* os;
	std::ostream* of1;
	std::ostream* of2;
	os = &std::cout;
	if(m_output_file1) of1 = new std::ofstream(m_output_file1);
	else of1 = &std::cout;
	if(m_output_file2) of2 = new std::ofstream(m_output_file2);
	else of2 = &std::cout;

	std::vector<BioSequence> batch;
	srand((unsigned)time(NULL));

	BioSequence seq;

	std::ifstream ifs(m_input_file1);
	FastaReader fas(ifs);
	while(fas.read(seq)){
			batch.push_back(seq);
	}

	std::ifstream ifs2(m_input_file2);
	std::ifstream ifs3(m_input_file3);
	std::ifstream ifs4(m_input_file4);
	std::ifstream ifs5(m_input_file5);

	M_MotifInfo info(batch, ifs2 ,ifs3, ifs4, ifs5);

	info.out_info(*of1);
	info.out_pwm(*of2);

	if (of1 != &std::cout) delete of1;
	if (of2 != &std::cout) delete of2;
	return 0;

}

//
void AppChk::usage()
{
	using std::cerr;
	using std::endl;
	cerr << "usage: " << m_prog << " [-key value ...]" << endl;
	cerr << "\tpossible keys and values are as follows:" << endl;
	cerr << "\td:input file1 [string] (optional; stdout by default)" << endl;
	cerr << "\td:input file2 [string] (optional; stdout by default)" << endl;
	cerr << "\td:input file3 [string] (optional; stdout by default)" << endl;
	cerr << "\td:input file4 [string] (optional; stdout by default)" << endl;
	cerr << "\td:input file5 [string] (optional; stdout by default)" << endl;
	cerr << "\to:output file1 [string] (optional; stdout by default)" << endl;
	cerr << "\tdebug: run in debug mode if set true [t/f] (f by default)" << endl;
}

//
void AppChk::SetParam::operator()(const Param& param)
{
	using std::strcmp;
	if(strcmp(param.key, "o1") == 0){
		m_obj->m_output_file1 = param.value;
	}else if(strcmp(param.key, "o2") == 0){
		m_obj->m_output_file2 = param.value;
	}else if(strcmp(param.key, "s") == 0){
		m_obj->m_input_file1 = param.value;
	}else if(strcmp(param.key, "p") == 0){
		m_obj->m_input_file2 = param.value;
	}else if(strcmp(param.key, "d") == 0){
		m_obj->m_input_file3 = param.value;
	}else if(strcmp(param.key, "l") == 0){
		m_obj->m_input_file4 = param.value;
	}else if(strcmp(param.key, "c") == 0){
		m_obj->m_input_file5 = param.value;
	}else if(strcmp(param.key, "debug") == 0){
		if(param.value[0] == 't') m_obj->m_debug = true;
		else m_obj->m_debug = false;
	} else {
		std::cerr << "unreorganized parameter " << param.key << std::endl;
		m_obj->usage();
		std::exit(2);
	}
}
