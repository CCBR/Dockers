#ifndef RMC_FASTA_READER_H
#define RMC_FASTA_READER_H

#include <iostream>
#include <string>
#include "bio_sequence.h"

namespace Rmc{

class FastaReader{
public:
	FastaReader(std::istream& is);
	bool read(BioSequence& seq);

private:
	std::istream& m_is;
	bool read_header(BioSequence& seq);
	void read_seq(BioSequence& seq);
	void read_id_annot(const std::string& header, BioSequence& seq);
};

}

#endif
	

