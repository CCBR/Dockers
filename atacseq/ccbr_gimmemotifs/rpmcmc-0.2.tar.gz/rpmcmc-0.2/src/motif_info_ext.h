#ifndef MOTIF_INFO_EXT_H
#define MOTIF_INFO_EXT_H

#include <iostream>
#include <string>
#include <vector>
#include "bio_sequence.h"

namespace Rmc{
	class M_MotifInfo {
	public:
		M_MotifInfo(std::vector<BioSequence>& a, std::istream& b,
		std::istream& c, std::istream& d, std::istream& e);
		void out_info(std::ostream& os);
		void out_pwm(std::ostream& os);

	private:
		std::istream& is1;
		std::istream& is2;
		std::istream& is3;
		std::istream& is4;

		std::vector<BioSequence > m_seqset;
		std::vector<int> index;
		std::vector<std::vector<int> > pos;
		std::vector<std::vector<int> > dir;
		std::vector<int> length;

		char complement(char c);
		int charnum(char c);
	};
}

#endif
