#ifndef RMC_MOTIF_SAMPLER_H
#define RMC_MOTIF_SAMPLER_H

#include <iostream>
#include <vector>
#include <string>
#include "bio_sequence.h"
#include "ps_prior.h"

#define ITER 10000
#define MOTIF 50

namespace Rmc{

class MotifSampler {
public:
	MotifSampler(std::vector<BioSequence>& mat, PsPrior& p, int m,
 int l_min, int l_max, double r, int n, double bound, double g);

	void mcmc_motif();
	void ini_parm();
	void filter_motif(double th1, double th2, int th3, int th4, std::ostream& os);

//
	void stock_likelihood(int t);
	void stock_pwm(int t);
	void stock_length(int t);
	void stock_weight(int t);
	void stock_seq_num(int t);

//
	void out_pwm(std::ostream& os);
	void out_pos(std::ostream& os);
	void out_dir(std::ostream& os);
	void out_weight(std::ostream& os);
	void out_eval(std::ostream& os);
	void out_length(std::ostream& os);
	void out_pwm_from_pos(std::ostream& os);

private:
	void th_update(int m);
	double theta_cond(int m, int p);
	double repulsion(int m);
	double dist_c(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2);
	double dist_c_inside(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2);
	double total_a(const double (&mat)[MOTIF][5][30], int (&length)[MOTIF], int m, int n);
	double alignment(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2);
	double alignment_inside(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2);
	double distance(const double (&mat1)[5][30], const double (&mat2)[5][30], int a1, int b1, int n);
	double r_distance(const double (&mat1)[5][30], const double (&mat2)[5][30], int length, int a1, int b1, int n);
	double get_likelihood(int a);
	double get_eval(int a);
	int active_seq(int motif);
	void get_count(int a);
	void get_countbg(int a);
	void calc_psp_all(int a);
	void back_update(int m);
	void k_update(int m);
	void u_update();
	void z_update();
	void change_pair(int i);

	std::vector<BioSequence > m_mat;
	PsPrior psp;
	double mat_motif[MOTIF][5][30];
	std::vector< std::vector< std::vector<int> > > s_mat; // base
	std::vector< std::vector< std::vector<int> > > b_mat; // bg

	std::vector< std::vector<int> > m_pos;
	std::vector< std::vector<int> > r_seq;
	int m_length[MOTIF];
	int n_motif;
	double b_g[MOTIF][257];
	int count_letters[257];
	int k_max;
	int k_min;
	int nbg;
	int markov;
	double ondo;
	double repul;
	int norm;
	bool edge1[MOTIF];
	bool edge2[MOTIF];
	double bound_motif;
	int nearest;
	double gap;
	double count_motif[5][30];
	double count_bg[257][30];
	double psp_val[MOTIF];

///////// 
	std::vector<double> r_likelihood;
	std::vector<double> r_weight;
	double r_motif [MOTIF*ITER][5][30]; 
	std::vector<int> r_length;
	std::vector<int> r_seq_num;
};

}
#endif
