#ifndef PS_PRIOR_H
#define PS_PRIOR_H

#include <iostream>
#include <string>
#include <vector>

namespace Rmc{
	class PsPrior{
	public:
		void set_prior(std::istream& is);
		void set_uniform(int row, int col);
		double get_element(int row, int col);
		double get_relement(int row, int col);
		int nrow();
		int ncol(int row);
		bool is_uniform();

	private:
		std::vector< std::vector<double> > m_prior;
		bool m_u;
	};


inline double PsPrior::get_element(int row, int col){ return m_prior[row][col]; }
inline double PsPrior::get_relement(int row, int col){ return m_prior[row][m_prior[row].size()-col-1]; }
inline int PsPrior::nrow(){ return m_prior.size();}
inline int PsPrior::ncol(int row){ return m_prior[row].size();}
inline bool PsPrior::is_uniform(){ return m_u;}


}

#endif
