/*
	*main.cpp:used by all Rmc applications
*/
#include "app.h"
extern Rmc::App* app;

int main(int argc, char *argv[])
{
	app->set_param_default();
	app->set_param(argv);
	return app->run();
}
