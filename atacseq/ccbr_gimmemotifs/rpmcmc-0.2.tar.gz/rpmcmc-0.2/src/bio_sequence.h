#ifndef RMC_BIO_SEQUENCE_H
#define RMC_BIO_SEQUENCE_H

#include <string>
#include <vector>
#include <iostream>

namespace Rmc{

class BioSequence{
public:
	virtual ~BioSequence();
	virtual void clear();
	void set_id(const std::string& id);
	void set_annot(const std::string& annot);
	void set_place(int n);
	void set_length(int l);
	void set_type(int t);
	void add(char c);
	void add(const std::string& seq);
	void print(std::ostream& os, int line_length = FASTA_LINE_LENGTH)const;
	static const int FASTA_LINE_LENGTH = 70;
	int motif_n();
	int motis(int n);
	int motil(int n);
	int motit(int n);
	std::string id() const;
	std::string annot() const;
	int length() const;
	char at(size_t i) const;
	const std::string& str() const;

private:
	std::string m_id;
	std::string m_annot;
	std::string m_seq;
	std::vector<int> m_p;									// ���`�[�t�̊J�n�ʒu�i��������̂�vector��)
	std::vector<int> m_l;									// ���`�[�t�̒����i��������̂�vector��)
	std::vector<int> m_t;									// ���`�[�t�̃^�C�v�i���Ԗڂ̍s�񂩂琶�����ꂽ��)
};

inline void BioSequence::set_id(const std::string& id){m_id = id;}
inline void BioSequence::set_annot(const std::string& annot){m_annot = annot;}
inline void BioSequence::set_place(int n){m_p.push_back(n);}
inline void BioSequence::set_length(int l){m_l.push_back(l);}
inline void BioSequence::set_type(int t){m_t.push_back(t);}
inline void BioSequence::add(char c){m_seq += c;}
inline void BioSequence::add(const std::string& seq){ m_seq += seq;}
inline std::string BioSequence::id() const{ return m_id; }
inline std::string BioSequence::annot() const { return m_annot; }
inline int BioSequence::motif_n() { return m_t.size(); }
inline int BioSequence::motis(int n) { return m_p[n]; }
inline int BioSequence::motil(int n) { return m_l[n]; }
inline int BioSequence::motit(int n) { return m_t[n]; }
inline int BioSequence::length() const { return m_seq.length(); }
inline char BioSequence::at(size_t i) const { return m_seq.at(i); }
inline const std::string& BioSequence::str() const{ return m_seq; }

}

#endif
