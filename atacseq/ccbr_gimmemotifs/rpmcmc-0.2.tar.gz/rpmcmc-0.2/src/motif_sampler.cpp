#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <cmath>
#include <omp.h>
#include "bio_sequence.h"
#include "motif_sampler.h"
#include "ps_prior.h"

using namespace Rmc;
using std::string;

///subroutine

//xorshift
	unsigned long my_xor128(){
  		static unsigned long x=123456789, y=362436069, z=521288629, w=88675123;
  		unsigned long t;
  		t=(x^(x<<11));
  		x=y; y=z; z=w;
  		return w=(w^(w>>19))^(t^(t>>8));
	}
//[0,1) uniform dist.
	double frand(){
  		return (double)rand() / ((double)RAND_MAX+1); 
	}
//gamma r.v.
	double gamma_rand(double shape, double scale){
		double n, b1, b2, c1, c2;
		if(4.0 < shape) n = 1.0/sqrt(shape);
		else if(0.4 < shape) n = 1.0/shape + (1.0/shape)*(shape-0.4)/3.6;
 	   else if(0.0 < shape) n = 1.0/shape;
  		else return -1;

  	b1 = shape - 1.0/n;
	b2 = shape + 1.0/n;

	if(0.4 < shape) c1 = b1 * (log(b1)-1.0) / 2.0;
	else c1 = 0;
	c2 = b2 * (log(b2)-1.0) / 2.0;

   while(true){
   	 double v1 = frand(), v2 = frand();
   	 double w1, w2, y, x;
   	 w1 = c1 + log(v1);
   	 w2 = c2 + log(v2);
   	 y = n * (b1*w2-b2*w1);
   	 if(y < 0) continue;
			x = n * (w2-w1);
   	 if(log(y) < x) continue;
 		   return exp(x) * scale;
		}
 	 return -1;
	}

///////////////////////////////////////////////////////////////////////////////////////


MotifSampler::MotifSampler(std::vector<BioSequence>& mat, PsPrior& p, int m,
 int l_min, int l_max, double r, int n, double bound, double g)
{
	m_mat = mat;
	psp = p;
	k_max = l_max;				 
       k_min= l_min;				
	n_motif = n;			
	ondo = 1.0;
	repul = r;
	bound_motif = 1/bound;
	nearest = 2;
	norm = 1;
	gap = g;
	markov = m;
	nbg = pow(4, markov+1);		

	std::vector< std::vector<int> > t_s;
	for(int j = 0; j < m_mat.size(); j++){
		std::vector<int> tt_s;									
		for(int i=0; i < m_mat[j].length(); i++){
			if(m_mat[j].at(i) == 'A'){ tt_s.push_back(0);} 
			else if(m_mat[j].at(i) == 'C'){  tt_s.push_back(1);}
			else if(m_mat[j].at(i) == 'G'){  tt_s.push_back(2);}
			else if(m_mat[j].at(i) == 'T'){  tt_s.push_back(3);}
			else {tt_s.push_back(4);}
		}
		t_s.push_back(tt_s);
	}

	s_mat.push_back(t_s);

	t_s.clear();
	for(int j = 0; j < m_mat.size(); j++){
		std::vector<int> tt_s;									
		for(int i=(m_mat[j].length()-1); i >=0; i--){
			if(m_mat[j].at(i) == 'A'){ tt_s.push_back(3);} 
			else if(m_mat[j].at(i) == 'C'){  tt_s.push_back(2);}
			else if(m_mat[j].at(i) == 'G'){  tt_s.push_back(1);}
			else if(m_mat[j].at(i) == 'T'){  tt_s.push_back(0);}
			else {tt_s.push_back(4);  }
		}
		t_s.push_back(tt_s);
	}
	s_mat.push_back(t_s);

	t_s.clear();
	for(int j = 0; j < m_mat.size(); j++){	
		std::vector<int> tt_s;								
		for(int i=0; i < m_mat[j].length(); i++){
			if(i < markov){tt_s.push_back(nbg);}
			else{
				int tmp=0;
				for(int p=0; p <= markov; p++){
				if(s_mat[0][j][i-p]<4){tmp += s_mat[0][j][i-p]*(int)pow(4,p);}
				else{tmp=nbg;break;}
				}
				tt_s.push_back(tmp);
			}
		}
		t_s.push_back(tt_s);
	}
	b_mat.push_back(t_s);

	t_s.clear();
	for(int j = 0; j < m_mat.size(); j++){	
		std::vector<int> tt_s;									
		for(int i=0; i < m_mat[j].length(); i++){
			if(i < markov){tt_s.push_back(nbg);}
			else{
				int tmp=0;
				for(int p=0; p <= markov; p++){
				if(s_mat[1][j][i-p]<4){tmp += s_mat[1][j][i-p]*(int)pow(4,p);}
				else{tmp=nbg;break;}
				}
				tt_s.push_back(tmp);	
			}
		}
		t_s.push_back(tt_s);
	}
	b_mat.push_back(t_s);
	ini_parm();	
}

void MotifSampler::mcmc_motif(){
	for(int i=0; i < n_motif; i++){
		double repul_prev = repul;
		repul = std::max(repul*active_seq(i) - 0.0 , 0.0);
		th_update(i);
		back_update(i); 
		k_update(i);
		repul = repul_prev;
	}
	u_update();
	z_update();
}

/// initialize
void MotifSampler::ini_parm(){
	for(int p=0; p < m_mat.size(); p++){	
		std::vector<int> tseq;										
		for(int j=0; j < n_motif; j++){
			tseq.push_back(0);
		}
		r_seq.push_back(tseq);
	}

	for(int j=0; j < n_motif; j++){
		for(int p=0; p < (nbg+1); p++){										
			b_g[j][p] = pow(0.25, markov);
		}
	}

	for(int j=0; j < n_motif; j++){
		m_length[j] = int(rand() % (k_max - k_min + 1) ) + k_min;			
	}

	for(int p = 0; p < (nbg+1); p++){
		count_letters[p] = 0;
	}

	for(int j = 0; j < b_mat[0].size(); j++){  // p-th markov background
		for(int p = 0; p < b_mat[0][j].size(); p++){
			++count_letters[b_mat[0][j][p]];
			++count_letters[b_mat[1][j][p]];
		}
	}

	for(int q = 0; q < n_motif; q++){
		for(int p = 0; p < 30 ; p++){
			double tmp[4]={0};
			for(int j = 0; j < 4; j++){							
				tmp[j] = gamma_rand(1, 1);
			}
			for(int j = 0; j < 4; j++){							
				mat_motif[q][j][p] = tmp[j]/(tmp[0] + tmp[1] + tmp[2] + tmp[3]);
			}
		}
	}

	for(int p=0; p < m_mat.size(); p++){	
		std::vector<int> tpos;									
		for(int j=0; j < n_motif; j++){								
			 tpos.push_back(int(rand() % (m_mat[p].length() - m_length[j]-1))+1);		
		}
		m_pos.push_back(tpos);
	}

	for(int p=0; p < n_motif; p++){
		edge1[p] = 0; edge2[p]=0;
	}
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////

void MotifSampler::th_update(int m){
	double pit = 0.05;
	get_count(m);										
	int motif_num = active_seq(m);

	for(int p = 0; p < m_length[m]; p++){
		double prev[4];								
		double px;
		double u;

		for(int v = 0; v < 4; v++){
			for(int j=0; j < 4; j++){
				prev[j] = mat_motif[m][j][p];
			}
			double maxx;
			double minx;
			px = theta_cond(m, p)+repulsion(m);
			u = px + log((double)rand() / ((double)RAND_MAX+1));
			double minu = px;
			
			while((minu > u) && (mat_motif[m][v][p] > 0.0)){
				mat_motif[m][v][p] = std::max((mat_motif[m][v][p] - pit), 0.0);
				mat_motif[m][(v+3)%4][p] = 1 - mat_motif[m][(v+1)%4][p] - mat_motif[m][(v+2)%4][p] - mat_motif[m][v][p];
	
				minu = theta_cond(m, p)+repulsion(m);	
			}
			minx = mat_motif[m][v][p];

			mat_motif[m][v][p] = prev[v];	
			mat_motif[m][(v+3)%4][p] = prev[(v+3)%4];
					
			double maxu; maxu = px;
			while((maxu > u) && ((mat_motif[m][v][p] + pit) < (1 - mat_motif[m][(v+1)%4][p] - mat_motif[m][(v+2)%4][p]))){
				mat_motif[m][v][p] = std::min((mat_motif[m][v][p] + pit), (1 - mat_motif[m][(v+1)%4][p] - mat_motif[m][(v+2)%4][p]));
				mat_motif[m][(v+3)%4][p]  = 1 - mat_motif[m][(v+1)%4][p] - mat_motif[m][(v+2)%4][p] -mat_motif[m][v][p];

				maxu = theta_cond(m, p)+repulsion(m);	
			}
		maxx = mat_motif[m][v][p];
		mat_motif[m][v][p] = (maxx - minx) * (double)rand() / ((double)RAND_MAX+1) + minx;
		mat_motif[m][(v+3)%4][p] = 1 - mat_motif[m][(v+1)%4][p] - mat_motif[m][(v+2)%4][p] - mat_motif[m][v][p];
		}
	}
}

double MotifSampler::theta_cond(int m, int p){
	double sum=0.0;
	for(int v=0; v < 4; v++){
	sum += log(mat_motif[m][v][p]) * count_motif[v][p];
	}
	return sum;
}

double MotifSampler::repulsion(int m){
	return - repul * total_a(mat_motif,  m_length, m, nearest);
}

double MotifSampler::dist_c(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2){
	if(l1 > l2){
		return(dist_c_inside(mat2, mat1, l2, l1));
	}
	else{
		return(dist_c_inside(mat1, mat2, l1, l2));
	}
}

double MotifSampler::dist_c_inside(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2){
	int diff = l2 - l1;
	double sli = (double)l1/4;
	double min_dist= 9999.0;
	for(int i=1; i <= sli; i++){
		double dist=0.0;
		double r_dist=0.0;
		for(int j=0; j < (l1-i); j++){
			dist += distance(mat1, mat2, (i+j), j, norm);
			r_dist += r_distance(mat1, mat2, l2, (i+j), j, norm); 
		}
		dist = std::min(dist, r_dist)*((double)l1/(l1-i));
		if(min_dist > dist){
			min_dist = dist;
		}
	}
	for(int i=0; i <= diff; i++){
		double dist=0.0;
		double r_dist=0.0;
		for(int j=0; j < l1; j++){
			dist += distance(mat1, mat2, j, (i+j), norm);
			r_dist += r_distance(mat1, mat2, l2, j, (i + j), norm); 
		}
		dist = std::min(dist, r_dist);
		if(min_dist > dist){
			min_dist = dist;
		}
	}
	for(int i=1; i <= sli; i++){
		double dist=0.0;
		double r_dist=0.0;
		for(int j=0; j < (l1-i); j++){
			dist += distance(mat1, mat2, j, (l2-l1+i+j), norm);
			r_dist += r_distance(mat1, mat2, l2, j, (l2-l1+i+j), norm); 
		}
		dist = std::min(dist, r_dist)*((double)l1/(l1-i));
		if(min_dist > dist){
			min_dist = dist;
		}
	}
	return ((min_dist*((double)l2/l1) + gap * diff)/l2);
}

double MotifSampler::total_a(const double (&mat)[MOTIF][5][30], int (&length)[MOTIF],  int m, int n){
	std::vector<double> rank;
	double score=0;
	for(int i=0; i < n_motif; i++){
		if(i != m){
			rank.push_back(alignment(mat[m], mat[i], length[m], length[i]));
		}
	}
	std::sort(rank.begin(),rank.end(),std::greater<double>());
	
	for(int i=0; i < n; i++){
		score += rank[i];
	}
	return score;
}

int MotifSampler::active_seq(int motif){
	int num=m_mat.size();
	for(int i=0; i < m_mat.size(); i++){
		if(r_seq[i][motif] ==2){
			num--;
		}
	}
	return(num);
}

double MotifSampler::alignment(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2){
	if(l1 > l2){
		return(alignment_inside(mat2, mat1, l2, l1));
	}
	else{
		return(alignment_inside(mat1, mat2, l1, l2));
	}

}

double MotifSampler::alignment_inside(const double (&mat1)[5][30], const double (&mat2)[5][30], int l1, int l2){
	int diff = l2 - l1;
	double sli = (double)l1/4;
	double max_score=0.0;
	for(int i=1; i <= sli; i++){
		double score=0.0;
		double r_score=0.0;
		for(int j=0; j < (l1-i); j++){
			score += 1.0 - distance(mat1, mat2, (i+j), j, norm);
			r_score += 1.0 - r_distance(mat1, mat2, l2, (i+j), j, norm);
		}
		score = std::max(score, r_score)*((double)l1/(l1-i));
		if(max_score < score){
			max_score = score;
		}
	}
	for(int i=0; i <= diff; i++){
		double score=0.0;
		double r_score=0.0;
		for(int j=0; j < l1; j++){
			score += 1.0 - distance(mat1, mat2, j, (i+j), norm);
			r_score += 1.0 - r_distance(mat1, mat2, l2, j, (i + j), norm); 
		}
		score = std::max(score, r_score);
		if(max_score < score){
			max_score = score;
		}
	}
	for(int i=1; i <= sli; i++){
		double score=0.0;
		double r_score=0.0;
		for(int j=0; j < (l1-i); j++){
			score += 1.0 - distance(mat1, mat2, j, (l2-l1+i+j), norm);
			r_score += 1.0 - r_distance(mat1, mat2, l2, j, (l2-l1+i+j), norm);
		}
		score = std::max(score, r_score)*((double)l1/(l1-i));
		if(max_score < score){
			max_score = score;
		}
	}
	return ((max_score*(double)l2/l1 - gap * diff)/l2);
}

double MotifSampler::distance(const double (&mat1)[5][30], const double (&mat2)[5][30], int a1, int b1, int n){
	double dist=0;
	if(n==1){
		for(int p = 0; p < 4; p++){
			dist += fabs(mat1[p][a1]-mat2[p][b1]);
		}
	}
	else{
		for(int p = 0; p < 4; p++){
			double t_dist=1.0;
			for(int i=0; i < n; i++){
				t_dist *= fabs(mat1[p][a1]-mat2[p][b1]);
			}
			dist += t_dist;
		}
	}
	if(n==1){ return dist/2.0;}
	else if(n==2){ return sqrt(dist/2.0);}
	else{ dist = pow(dist/2.0, 1.0/n);
		return dist;
	}
}

double MotifSampler::r_distance(const double (&mat1)[5][30], const double (&mat2)[5][30], int length, int a1, int b1, int n){
	double dist=0;
	if(n==1){
		for(int p = 0; p < 4; p++){
			dist += fabs(mat1[p][a1]-mat2[abs(p-3)][length - b1 -1]);
		}
	}
	else{
		for(int p = 0; p < 4; p++){
			double t_dist=1.0;
			for(int i=0; i < n; i++){
				t_dist *= fabs(mat1[p][a1]-mat2[abs(p-3)][length - b1 -1]);
			}
			dist += t_dist;
		}
	}
	if(n==1){ return dist/2.0;}
	else if(n==2){ return sqrt(dist/2.0);}
	else{ dist = pow(dist/2.0, 1.0/n);
		return dist;
	}
}

double MotifSampler::get_likelihood(int a){
	get_count(a);
	get_countbg(a);
	calc_psp_all(a);
	double likelihood = psp_val[a];
	for(int i = 0; i < m_length[a]; i++){
		for(int v=0; v < 4; v++){
			likelihood += (count_motif[v][i]*ondo)*log(mat_motif[a][v][i]);
		}
		for(int v=0; v < nbg; v++){
			likelihood -= (count_bg[v][i]*ondo)*log(b_g[a][v]);
		}
	}

	return likelihood;
}

double MotifSampler::get_eval(int a){
	if(active_seq(a)==0){
		return -999999;
	}
	else{
		double eval = get_likelihood(a);
		eval = eval - log(bound_motif)*active_seq(a)*m_length[a]*ondo;
		eval += repulsion(a);
		return eval;
	}
}

void MotifSampler::get_count(int a){
	if(active_seq(a) == 0){
		for(int v=0; v < 4; v++){
			for(int p = 0; p < m_length[a] ; p++){
					count_motif[v][p] = 1.0;
			}
		}	
	}
	else{
		for(int v=0; v < 4; v++){
			for(int p = 0; p < m_length[a] ; p++){
					count_motif[v][p] = 0.0;
			}
		}	
		for(int j = 0; j < m_mat.size() ; j++){	
			for(int p = 0; p < m_length[a] ; p++){
				if(r_seq[j][a] < 2){
					count_motif[s_mat[ r_seq[j][a] ][j][ m_pos[j][a] + p ]][p] += 1.0;
				}
			}
		}
	}
}

void MotifSampler::get_countbg(int a){
	if(active_seq(a) == 0){
		for(int v=0; v < (nbg+1); v++){
			for(int p = 0; p < m_length[a] ; p++){
					count_bg[v][p] = 1.0;
			}
		}	
	}
	else{
		for(int v=0; v < (nbg+1); v++){
			for(int p = 0; p < m_length[a] ; p++){
					count_bg[v][p] = 0.0;
			}
		}	
		for(int j = 0; j < m_mat.size() ; j++){	
			for(int p = 0; p < m_length[a] ; p++){
				if(r_seq[j][a] < 2){
					count_bg[b_mat[ r_seq[j][a] ][j][ m_pos[j][a] + p ]][p] += 1.0;
				}
			}
		}
	}
}

void MotifSampler::calc_psp_all(int a){
	psp_val[a]=0;
	if(active_seq(a) == 0){psp_val[a] = 0;}
	else if(psp.is_uniform()){psp_val[a] = 0;}
	else{
		for(int j = 0; j < m_mat.size() ; j++){	
			if(r_seq[j][a] ==0){
				for(int p = 0; p < m_length[a] ; p++){
					psp_val[a] += log(psp.get_element(j, m_pos[j][a]+p));
				}
			}
			else if(r_seq[j][a] ==1){
				for(int p = 0; p < m_length[a] ; p++){
					psp_val[a] += log(psp.get_relement(j, m_pos[j][a]+p));
				}
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void MotifSampler::back_update(int m){
	double bg_letters[257] = {0};
	for(int j=0; j < (nbg+1); j++){
		bg_letters[j] = count_letters[j];
	}
	#pragma omp parallel for				                    
	for(int j=0; j < m_mat.size(); j++){
		for(int col=0; col < m_length[m]; col++){
			if( r_seq[j][m] < 2 ){
				--bg_letters[ b_mat[ r_seq[j][m] ][j][ m_pos[j][m] + col ] ];
			}
		}
	}

	int total_bg = 0;
	for(int j=0; j < (nbg+1); j++){
		total_bg += bg_letters[j];
	}

	for(int j=0; j < (nbg+1); j++){
		b_g[m][j] = bg_letters[j] / (double)total_bg;
		b_g[m][j] = pow(b_g[m][j], 1/((double)markov+1));
	}
}

void MotifSampler::k_update(int m){
	double transit_prob[5];
	if((edge1[m] == 1) && (edge2[m] == 1) && (m_length[m] == k_min)){
		transit_prob[0] = 0; transit_prob[1]=0; transit_prob[2]=1.0; transit_prob[3]=0; transit_prob[4]=0;
	}
	else if(m_length[m] == k_max){
		transit_prob[0] = 0.33; transit_prob[1]=0.33; transit_prob[2]=0.34; transit_prob[3]=0; transit_prob[4]=0;
	}
	else if((edge1[m] == 1) && (edge2[m] == 1)){
		transit_prob[0] = 0.33; transit_prob[1]=0.33; transit_prob[2]=0.34; transit_prob[3]=0; transit_prob[4]=0;
	}
	else if((m_length[m] == k_min) && (edge1[m] == 1) ){
		transit_prob[0] = 0; transit_prob[1]=0; transit_prob[2]=0.5; transit_prob[3]=0; transit_prob[4]=0.5;
	}
	else if((m_length[m] == k_min) && (edge2[m] == 1) ){
		transit_prob[0] = 0; transit_prob[1]=0; transit_prob[2]=0.5; transit_prob[3]=0.5; transit_prob[4]=0;
	}
	else if(m_length[m] == k_min){
		transit_prob[0] = 0; transit_prob[1]=0; transit_prob[2]=0.34; transit_prob[3]=0.33; transit_prob[4]=0.33;
	}
	else if(edge1[m] == 1){
		transit_prob[0] = 0.25; transit_prob[1]=0.25; transit_prob[2]=0.25; transit_prob[3]=0; transit_prob[4]=0.25;
	}
	else if(edge2[m] == 1){
		transit_prob[0] = 0.25; transit_prob[1]=0.25; transit_prob[2]=0.25; transit_prob[3]=0.25; transit_prob[4]=0;
	}
	else{transit_prob[0] = 0.2; transit_prob[1]=0.2; transit_prob[2]=0.2; transit_prob[3]=0.2; transit_prob[4]=0.2;}

	for(int j = 0; j < 4; j++){
		transit_prob[j+1] += transit_prob[j];
	}

	double temp_mat[5][30]={0};
	double r = (double)rand() / ((double)RAND_MAX+1);
	int check = 0;
	while( r > transit_prob[check]){++check;}
	if(check==0){	
		double prev_prob;
		double next_prob;
		prev_prob = get_eval(m);

		for(int i = 0; i < m_length[m]; i++){
			for(int v = 0; v < 4; v++){
				temp_mat[v][i] = mat_motif[m][v][i];
			}
		}
		for(int v=0; v < 4; v++){
			for(int p=0; p < m_length[m]-1; p++){
				mat_motif[m][v][p] = mat_motif[m][v][p+1];
			}
		}
		m_length[m] -= 1;
		for(int j = 0; j < m_mat.size(); j++){
			m_pos[j][m] += 1;
		}
		next_prob = get_eval(m);

  	double r = (double)rand() / ((double)RAND_MAX+1);
		if( r > (next_prob/prev_prob)){	
			m_length[m] += 1;
			for(int i = 0; i < m_length[m]; i++){
				for(int v = 0; v < 4; v++){
					mat_motif[m][v][i] = temp_mat[v][i];
				}
			}
			for(int j = 0; j < m_mat.size(); j++){
				m_pos[j][m] -= 1;
			}
		}
	}

	else if(check==1){
		double prev_prob;
		double next_prob;

		prev_prob = get_eval(m);

		for(int i = 0; i < m_length[m]; i++){
			for(int v = 0; v < 4; v++){
				temp_mat[v][i] = mat_motif[m][v][i];
			}
		}
		m_length[m] -= 1;
		next_prob = get_eval(m);

   		double r = (double)rand() / ((double)RAND_MAX+1);
		if( r > (next_prob/prev_prob)){	
			m_length[m] += 1;
			for(int i = 0; i < m_length[m]; i++){
				for(int v = 0; v < 4; v++){
					mat_motif[m][v][i] = temp_mat[v][i];
				}
			}
		}
	}
	else if(check==2){;}
	else if(check==3){
		double prev_prob;
		double next_prob;
		prev_prob = get_eval(m);
		for(int i = 0; i < m_length[m]; i++){
			for(int v = 0; v < 4; v++){
				temp_mat[v][i] = mat_motif[m][v][i];
			}
		}
		
		for(int v=0; v < 4; v++){
			for(int p=(m_length[m]-1); p >= 0; p--){
				mat_motif[m][v][p+1] = mat_motif[m][v][p];
			}
		}
		m_length[m] += 1;
		for(int j = 0; j < m_mat.size(); j++){
			m_pos[j][m] -= 1;
		}
		get_count(m);

		double tmp[4]={0};
		for(int j = 0; j < 4; j++){												
			tmp[j] = gamma_rand( count_motif[j][0], 1);
		}
		for(int j = 0; j < 4; j++){												
			mat_motif[m][j][0] = tmp[j]/(tmp[0] + tmp[1] + tmp[2] + tmp[3]);
		}

		next_prob = get_eval(m);
 		double r = (double)rand() / ((double)RAND_MAX+1);
		if( r > (next_prob/prev_prob)){
			m_length[m] -= 1;
			for(int i = 0; i < m_length[m]; i++){
				for(int v = 0; v < 4; v++){
					mat_motif[m][v][i] = temp_mat[v][i];
				}
			}
			for(int j = 0; j < m_mat.size(); j++){
				m_pos[j][m] += 1;
			}
		}
	}

	else if(check==4){
		double prev_prob=1.0;
		double next_prob=1.0;

		prev_prob = get_eval(m);

		++m_length[m];
		get_count(m);

		double tmp[4]={0};
		for(int j = 0; j < 4; j++){												
			tmp[j] = gamma_rand( count_motif[j][m_length[m]-1], 1);
		}
		for(int j = 0; j < 4; j++){												
			mat_motif[m][j][m_length[m]-1] = tmp[j]/(tmp[0] + tmp[1] + tmp[2] + tmp[3]);
		}

		next_prob = get_eval(m);

   		double r = (double)rand() / ((double)RAND_MAX+1);
		if( r > (next_prob/prev_prob)){
			--m_length[m];
		}
	}
}

void MotifSampler::u_update(){
	for(int i = 0; i < n_motif; i++){
		edge1[i] = 0; edge2[i]= 0;
	}
	double motif_ht[MOTIF][257][30]={0};
	for(int q = 0; q < n_motif; q++){
		for(int p = 0; p < m_length[q]; p++){
			for(int k=0; k < nbg; k++){
			motif_ht[q][k][p] = mat_motif[q][k % 4][p];
			}

			for(int k=0; k < nbg; k++){
				motif_ht[q][k][p] /= b_g[q][k];
			}
			motif_ht[q][nbg][p] = 0;
		}
	}

	for(int j = 0; j < m_mat.size(); j++){
		for(int q = 0; q < n_motif; q++){
			double array_post[6500]={0};
			int r_start = m_mat[j].length()-m_length[q]+1;
			if(psp.is_uniform()){
				#pragma omp parallel for
				for(int col=markov+1; col < r_start-markov-1; col++){
					array_post[col] = 1;								
					array_post[col + r_start] = 1;
					for(int p = 0; p < m_length[q]; p++){
						array_post[col] *= motif_ht[q][b_mat[0][j][col+p]][p];
						array_post[col + r_start] *= motif_ht[q][b_mat[1][j][col+p]][p];
					}
				}
			}else{
				double psp_v[6500]={1};
				for(int col=markov+1; col < r_start-markov-1; col++){
					psp_v[col] *= psp.get_element(j, col);
					psp_v[col + r_start] *= psp.get_relement(j, col);
				}
				#pragma omp parallel for
				for(int col=markov+1; col < r_start-markov-1; col++){
					psp_v[col] = psp.get_element(j, col+m_length[q]-1)*psp_v[col-1]/psp.get_element(j, col-1);
					psp_v[col+r_start] = 
						psp.get_relement(j, col)*psp_v[col+r_start-1]/psp.get_relement(j, col-1);
				}			
				#pragma omp parallel for
				for(int col=markov+1; col < r_start-markov-1; col++){
					array_post[col] = psp_v[col];								
					array_post[col + r_start] = psp_v[col + r_start];
					for(int p = 0; p < m_length[q]; p++){
						array_post[col] *= motif_ht[q][b_mat[0][j][col+p]][p];
						array_post[col + r_start] *= motif_ht[q][b_mat[1][j][col+p]][p];
					}
				}
	
			}

			double temp_sum = 0.0;
			for(int col = 0; col < 2*r_start; col++){			
				 temp_sum += array_post[col];
			}
			for(int col = 0; col < 2*r_start-1; col++){
				array_post[col] = array_post[col] / temp_sum;
			}			

			double cdf_post[6001];
			for(int col = 0; col < 2*r_start; col++){
				 cdf_post[col] = array_post[col];
			}
			for(int col = 0; col < (2*r_start-1); col++){
				 cdf_post[col+1] += cdf_post[col];
			}

			double r = (double)rand() / ((double)RAND_MAX+1);
			int next = 0;
			while( r > cdf_post[next]){++next;}
			if(next < r_start){
				r_seq[j][q] = 0;
			}else{ 
				r_seq[j][q] = 1;
				next = next % r_start;
			}
 
			m_pos[j][q] = next;	
		}
	}
}
//////////////////////////////////////////
void MotifSampler::z_update(){
	#pragma omp parallel for
	for(int q = 0; q < n_motif; q++){
		for(int j = 0; j < m_mat.size(); j++){
		
			double likelihood = 1.0;
			for(int l = 0; l < m_length[q]; l++){
				likelihood *= mat_motif[q][s_mat[ r_seq[j][q] ][j][l + m_pos[j][q]] ][l]
							/b_g[q][b_mat[ r_seq[j][q] ][j][l + m_pos[j][q]] ];
			}
			likelihood = pow( likelihood, ondo);
			likelihood /= pow( bound_motif, m_length[q]*ondo );

			double r = (double)rand() / ((double)RAND_MAX+1);
			if( r > (likelihood/(likelihood + 1 ))){
				r_seq[j][q] = 2;
			}
		}	
	}
}
//////////////////////////////////////////
void MotifSampler::filter_motif(double th1, double th2, int th3, int th4, std::ostream& os){
	double tmp=gap; gap=th1;
	int tmp_norm = norm; norm = th3;
	std::vector < std::vector <int> > fil_motif;
	int total_motif = 0;
	int chosen_motif_num = 0;
	int exist_number = 0;
	bool existence[ITER*MOTIF] = {0};
	for(int i = 0; i < r_likelihood.size(); i++){
		if(r_seq_num[i] >= 0){
			total_motif++;
		}
		if((r_likelihood[i] >= -99999999.0) && (r_seq_num[i] >= th4)){
			exist_number++;
			existence[i] = 1;
		}
	}

	int it=0;
	while(exist_number >0 ){
		std::vector<int> cluster;
		int argmax=0;
		double max_likelihood = -9999999999.0;
		for(int i=0; i < total_motif; i++){
			if( existence[i] == 1){
				if( r_likelihood[i] > max_likelihood){
					argmax = i;
					max_likelihood = r_likelihood[i];
				}
			}
		}
		cluster.push_back(argmax);
		chosen_motif_num++;

		existence[argmax] = 0;
		exist_number--;

		for(int i=0; i < total_motif; i++){
			if(existence[i]==1){
				if(dist_c(r_motif[argmax], r_motif[i], r_length[argmax], r_length[i]) < th2 ){
					cluster.push_back(i);
					existence[i] = 0;
					exist_number--;
				}
			}
		}
		it++;
		fil_motif.push_back(cluster);
	}
	gap = tmp;
	for(int i=0; i < fil_motif.size(); i++){
		for(int j=0; j < fil_motif[i].size(); j++){
			os << fil_motif[i][j] << " ";
		}
		os << std::endl;
	}
}

void MotifSampler::stock_weight(int t){
	int start = t*n_motif;
	for(int i=0; i < n_motif; i++){
		r_weight.push_back(-repulsion(i));
	}
}

void MotifSampler::stock_seq_num(int t){
	for(int i=0; i < n_motif; i++){
		r_seq_num.push_back(active_seq(i));
	}
}

void MotifSampler::stock_likelihood(int t){
	int start = t*n_motif;
	for(int i=0; i < n_motif; i++){
		int tmp_seq_num = active_seq(i);
		double tmp = get_likelihood(i) - log(bound_motif)*(double)tmp_seq_num*m_length[i];
		r_likelihood.push_back(tmp);
	}
}

void MotifSampler::stock_pwm(int t){
	int start = t*n_motif;
	for(int i = 0; i < n_motif; i++){
		get_count(i);
		for(int p = 0; p < k_max; p++){
			double temp_sum=0;
			for(int v = 0; v < 4; v++){
				temp_sum += (count_motif[v][p]-1);
			}
			if(temp_sum > 0){
				for(int v = 0; v < 4; v++){
					r_motif[i+start][v][p] = (count_motif[v][p]-1)/temp_sum;
				}
			}
		}
	}

}

void MotifSampler::stock_length(int t){
	int start = t*n_motif;
	for(int q = 0; q < n_motif; q++){
		r_length.push_back(m_length[q]);
	}
}

void MotifSampler::out_pwm(std::ostream& os){
	for(int i = 0; i < n_motif; i++){
		for(int j = 0; j < 4; j++){
			for(int p = 0; p < k_max; p++){
				if(p < m_length[i]){
					os << mat_motif[i][j][p] << " ";
				}
				else{
					os << 0 << " ";
				}
			}
			os << std::endl;
		}
	}
}

void MotifSampler::out_pwm_from_pos(std::ostream& os){
	std::vector <double> sum;
	for(int i = 0; i < n_motif; i++){
		get_count(i);
		sum.clear();

		for(int p = 0; p < k_max; p++){
			double t_sum=0;
			for(int v = 0; v < 4; v++){
				t_sum += count_motif[v][p]-1;
			}
			sum.push_back(t_sum);
		}
		for(int v = 0; v < 4; v++){
			for(int p = 0; p < k_max; p++){
				if(sum[p]==0){
					os << 0 << " ";
				}
				else if(p >= m_length[i]){
					os << 0 << " ";
				}
				else{
					os << (count_motif[v][p]-1)/sum[p] << " ";
				}
			}
			os << std::endl;
		}
	}
}

void MotifSampler::out_pos(std::ostream& os){
	for(int i = 0; i < n_motif; i++){
		for(int j = 0; j < m_mat.size(); j++){
			if( r_seq[j][i] == 0){
				os << m_pos[j][i] << " ";
			}
			else if( r_seq[j][i] == 1 ){
				os << (m_mat[j].length()-m_pos[j][i]) << " ";
			}
			else{os << -9999 << " ";}
		}
		os << std::endl;
	}
}

void MotifSampler::out_dir(std::ostream& os){
	for(int i = 0; i < n_motif; i++){
		for(int j = 0; j < m_mat.size(); j++){
			os << r_seq[j][i] << " ";
		}
		os << std::endl;
	}
}

void MotifSampler::out_weight(std::ostream& os){

	for(int i = 0; i < n_motif; i++){
		os << -repulsion(i) << " ";
	}
	os << std::endl;
}

void MotifSampler::out_eval(std::ostream& os){
	for(int i=0; i < n_motif; i++){
	int motif_num = active_seq(i);
		double eval=0;
		for(int j=0; j < m_mat.size(); j++){
			if(r_seq[j][i] < 2){
				for(int p=0; p < m_length[i]; p++){
					eval += log(mat_motif[i][ s_mat[ r_seq[j][i] ][j][ m_pos[j][i] + p] ][p]
								/ b_g[i][ b_mat[ r_seq[j][i] ][j][ m_pos[j][i] + p] ]);
				}
			eval -= repul *motif_num * total_a(mat_motif, m_length,  i, nearest);
			}
		os << eval << " ";
		}
	}
	os << std::endl;
}

void MotifSampler::out_length(std::ostream& os){
	for(int q = 0; q < n_motif; q++){
		os << m_length[q] << " ";
	}
	os << std::endl;
}
