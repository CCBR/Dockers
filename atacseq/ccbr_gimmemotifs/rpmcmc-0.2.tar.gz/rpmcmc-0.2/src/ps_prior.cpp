#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <vector>
#include "ps_prior.h"
using namespace Rmc;

void PsPrior::set_prior(std::istream& is){
	m_prior.clear();
	m_u = false;
	int num = 0;
	std::string str;

	while(getline(is, str))
	{	
		std::vector<double> tmp_vec;
		std::string tmp;
		std::istringstream stream(str);
		
		bool flag = false;
		int count = 0;
		while( getline(stream, tmp, ' '))
		{
			if((tmp.at(0) == '>') && (count==0)){flag=true; stream.unget();break;}
			else if(std::isspace(tmp.at(0))!=0){stream.unget();break;}
			else if(std::atof(tmp.c_str()) < 0){stream.unget();break;}
			else{
				tmp_vec.push_back(std::atof(tmp.c_str()));		
				}

			count += 1;
		}
		if(flag == false){m_prior.push_back(tmp_vec);}
	}
}

void PsPrior::set_uniform(int row, int col){
	m_prior.clear();
	m_u = true;
	m_prior.resize(row, std::vector<double>(col, 1.0));
}


