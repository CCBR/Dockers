#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <vector>
#include "motif_info_ext.h"
using namespace Rmc;

M_MotifInfo::M_MotifInfo(std::vector<BioSequence>& a, std::istream& b, std::istream& c, std::istream& d, std::istream& e): m_seqset(a), is1(b), is2(c), is3(d), is4(e)
{
	std::string str;
	while(getline(is1, str))
	{
		std::string tmp;
		std::istringstream stream(str);

		bool flag=0;
		while( (getline(stream, tmp, ' ')) && (flag==0) )
		{
			index.push_back(std::atoi(tmp.c_str()));
			flag = 1;
		}
	}

	for(int i=0; i < index.size(); i++){
		std::vector<int> tmp;
		pos.push_back(tmp);
	}

	int num = 0;
	std::string str2;
	while(getline(is2, str2))
	{
		for(int i=0; i < index.size(); i++){		
			std::string tmp;
			std::istringstream stream(str2);
			if(num == index[i]){
				while( getline(stream, tmp, ' ') )
				{
					pos[i].push_back(std::atoi(tmp.c_str()));
				}
			}
		}
		num += 1;
	}

	for(int i=0; i < index.size(); i++){
		std::vector<int> tmp;
		dir.push_back(tmp);
	}

	num = 0;
	std::string str3;
	while(getline(is3, str3))
	{
		for(int i=0; i < index.size(); i++){
			std::string tmp;
			std::istringstream stream(str3);
			if(num == index[i]){
				while( getline(stream, tmp, ' ') )
				{
					dir[i].push_back(std::atoi(tmp.c_str()));
				}
			}
		}
		num += 1;
	}

	std::vector<int> l;
	std::string str4;
	while(getline(is4, str4))
	{
		std::string tmp;
		std::istringstream stream(str4);

		while(getline(stream, tmp, ' '))
		{
			l.push_back(std::atoi(tmp.c_str()));
		}
	}

	for(int j=0; j < index.size(); j++){
		length.push_back(l[index[j]]);
	}
}

void M_MotifInfo::out_pwm(std::ostream& os){
	os << "PFM from RPMCMC result" << std::endl;
	os << std::endl;
		
	for(int i=0; i < index.size(); i++){

		std::vector<std::vector<int> > ppm;
		for(int j=0; j < length[i]; j++){
			std::vector<int> tmp(5);
			ppm.push_back(tmp);
		}

		os << "Motif" << (i+1) << std::endl;
		os << "A C G T" << std::endl;
		for(int j=0; j < pos[i].size(); j++){
			if(dir[i][j] == 0){
				int left = pos[i][j];
				for(int k=0; k < length[i]; k++){
					++ppm[k][charnum(m_seqset[j].at(left+k))];
				}
			}
			else if(dir[i][j] == 1){
				int right = pos[i][j]-1;
				for(int k=0; k < length[i]; k++){
					++ppm[k][charnum(complement(m_seqset[j].at(right - k)))];
				}
			}
		}
		for(int k=0; k < length[i]; k++){
			for(int j=0; j < 4; j++){
				os << ppm[k][j] << " ";
			}
			os << std::endl;
		}
		os << std::endl;
	}
}

void M_MotifInfo::out_info(std::ostream& os){
	os << "Motif Location from RPMCMC result" << std::endl;
	os << std::endl;
	for(int i=0; i < index.size(); i++){
		os << "Motif" << (i+1) << std::endl;
		os << "seq_no start end direction motifSeq" << std::endl;
		for(int j=0; j < pos[i].size(); j++){
			if(dir[i][j] == 0){
				int left = pos[i][j];
				int right = pos[i][j]+length[i]-1;
				os << j+1 << " " << left<< " " << right << " " << "+" << " ";
				for(int k=0; k < length[i]; k++){
					os << m_seqset[j].at(left+k);
				}
				os << std::endl;
			}
			else if(dir[i][j] == 1){
				int right = pos[i][j]-1;
				int left = pos[i][j]-length[i];
				os << j+1 << " " << left<< " " << right << " " << "-" << " ";
				for(int k=0; k < length[i]; k++){
					os << complement(m_seqset[j].at(right - k));
				}
				os << std::endl;
			}
		}
		os << std::endl;
	}
}

char M_MotifInfo::complement(char c){
	if(c == 'A' || c == 'a') return 'T';
	if(c == 'C' || c == 'c') return 'G';
	if(c == 'G' || c == 'g') return 'C';
	if(c == 'T' || c == 't') return 'A';
	if(c == 'U' || c == 'u') return 'A';
	if(c == 'R' || c == 'r') return 'Y';
	if(c == 'Y' || c == 'y') return 'R';
	return 'N';
}

int M_MotifInfo::charnum(char c){
	if(c == 'A' || c == 'a') return 0;
	if(c == 'C' || c == 'c') return 1;
	if(c == 'G' || c == 'g') return 2;
	if(c == 'T' || c == 't') return 3;
	return 4;
}
