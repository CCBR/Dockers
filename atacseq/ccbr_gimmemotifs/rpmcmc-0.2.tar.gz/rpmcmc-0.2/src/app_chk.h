#ifndef APP_CHK_H
#define APP_CHK_H

#include <functional>
#include <iostream>
#include <fstream>
#include <vector>
#include "app.h"

namespace Rmc{

class AppChk : public App{
public:
	AppChk();
	void set_param_default();
	void set_param(char *argv[]);
	int run();

private:
	void usage();
	char* m_input_file1;
	char* m_input_file2;
	char* m_input_file3;
	char* m_input_file4;
	char* m_input_file5;
	char* m_output_file1;
	char* m_output_file2;

	class SetParam : public std::unary_function<Param, void>{
	public:
		SetParam(AppChk* obj) : m_obj(obj){}
		void operator()(const Param& param);
	private:
		AppChk* m_obj;
	};
	friend class SetParam;
};

}
#endif
